import{h as o}from"./axios.e8a5cbbb.js";const s="/login";function p(t){return o.post(s,t)}const n="/register";function e(t){return o.post(n,t)}export{e as a,p};
