import{a0 as t}from"./vendor.aad8767c.js";const s=t("user",{state:()=>({uid:"",accountType:new Array}),getters:{},actions:{setUid(e){this.uid=e}}});export{s as u};
